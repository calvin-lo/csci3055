(require 'csci3055.a2.quicksort)

(println (csci3055.a2.quicksort/quicksort 4 2 9 8 5 6 3 1 7 0))